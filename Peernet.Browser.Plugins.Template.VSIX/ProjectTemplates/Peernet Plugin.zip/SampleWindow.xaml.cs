﻿using $safeprojectname$.ViewModels;
using System.Windows;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for SampleWindow.xaml
    /// </summary>
    public partial class SampleWindow : Window
    {
        public SampleWindow(SampleViewModel sampleViewModel)
        {
            InitializeComponent();
            DataContext = sampleViewModel;
        }
    }
}