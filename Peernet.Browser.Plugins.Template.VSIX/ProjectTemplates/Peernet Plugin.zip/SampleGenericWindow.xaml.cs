﻿using $safeprojectname$.ViewModels;
using System.Windows;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for SampleGenericWindow.xaml
    /// </summary>
    public partial class SampleGenericWindow : Window
    {
        public SampleGenericWindow(SampleGenericViewModel sampleGenericViewModel)
        {
            InitializeComponent();
            DataContext = sampleGenericViewModel;
        }
    }
}