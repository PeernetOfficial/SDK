﻿using Peernet.SDK.Models.Presentation;

namespace $safeprojectname$.ViewModels
{
    public class SampleViewModel : ViewModelBase
    {
    }
}