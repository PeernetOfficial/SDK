﻿using Microsoft.Extensions.DependencyInjection;
using $safeprojectname$.Services;
using Peernet.SDK.Models.Plugins;

namespace $safeprojectname$
{
    public class SamplePlugin : IPlugin
    {
        public void Load(ServiceCollection services)
        {
            services.AddSingleton<IPlayButtonPlug, SampleService>();
        }
    }
}